import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [0,0,0,0,0,0,1,37,34,10,-9,2,3,-10,-3,-2,0,7,]
disgust = [0,0,0,0,0,0,0,5,10,-1,11,-1,-3,11,2,3,0,-8,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,0,0,0,2,1,-3,-1,0,0,0,0,0,0,0,0,]
neutral = [0,0,0,0,0,0,-4,-46,-38,-8,-2,-1,0,0,0,0,0,0,]
contempt = [0,0,0,0,0,0,1,4,-3,-1,0,0,-1,0,1,-1,0,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
