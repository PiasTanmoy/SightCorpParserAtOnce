import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,0,0,0,0,1,1,1,1,1,2,1,1,1,1,3,]
anger = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,]
disgust = [0,0,0,0,0,0,0,1,2,3,3,3,3,2,1,4,]
fear = [0,0,0,0,0,1,1,1,2,2,5,3,2,4,2,4,]
sadness = [3,12,11,19,47,58,61,71,71,79,71,70,87,78,88,74,]
neutral = [96,87,87,80,51,40,37,24,21,12,17,20,5,12,8,13,]
contempt = [0,1,1,1,1,0,1,1,3,3,3,3,2,3,1,2,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
