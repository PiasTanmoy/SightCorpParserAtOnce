import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [0,0,0,0,0,1,8,20,29,40,44,47,51,50,31,]
disgust = [0,0,0,0,0,0,1,1,2,1,1,1,1,2,3,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [1,1,1,1,3,6,12,7,13,7,6,6,9,16,21,]
neutral = [98,99,99,99,97,93,76,70,52,49,44,38,31,25,22,]
contempt = [1,0,1,0,0,1,3,3,4,3,5,8,8,7,23,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
