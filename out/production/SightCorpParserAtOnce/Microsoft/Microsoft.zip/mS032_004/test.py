import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,0,0,0,0,0,0,0,0,0,0,1,0,0,]
surprise = [0,0,0,0,0,0,1,1,1,1,1,1,1,0,]
anger = [0,0,0,1,7,17,25,31,27,31,32,29,29,28,]
disgust = [0,0,0,0,1,3,6,10,12,15,22,16,21,28,]
fear = [0,0,0,0,0,1,0,1,1,4,6,5,7,7,]
sadness = [0,0,1,6,10,21,12,15,25,32,30,24,31,32,]
neutral = [99,99,99,92,80,55,53,40,32,15,8,23,9,4,]
contempt = [0,0,0,1,2,3,3,2,2,2,1,2,1,1,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
