import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,]
anger = [1,1,1,3,2,10,10,29,24,29,30,30,40,34,44,41,]
disgust = [0,0,0,0,0,1,1,7,11,17,24,31,35,36,33,41,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [5,2,6,5,14,13,16,6,5,8,7,4,4,2,5,4,]
neutral = [89,96,91,90,82,73,72,54,52,44,38,31,19,23,14,12,]
contempt = [5,1,2,2,2,4,2,3,8,3,2,3,3,4,3,2,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
