import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,0,0,0,0,0,0,0,0,0,0,2,12,54,-11,-8,21,-38,17,10,-8,-10,-32,32,-24,-13,-2,4,2,-1,-5,-1,]
surprise = [0,0,0,0,0,0,0,0,0,0,0,1,-1,0,0,0,0,0,0,0,0,0,1,-1,0,0,0,0,0,0,0,1,]
anger = [-1,2,-1,1,1,-1,-1,3,-3,3,-1,-2,-1,0,0,0,0,0,0,0,0,2,-1,0,0,3,8,7,-5,-5,5,1,]
disgust = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,-1,1,0,7,0,0,-6,1,4,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,-1,0,0,0,0,0,0,0,1,]
sadness = [-5,1,4,-6,4,-1,-4,4,-4,5,-1,-4,-2,1,1,-1,0,5,-5,1,3,-2,25,-25,0,0,12,-9,0,-4,2,21,]
neutral = [4,-4,-2,6,-6,2,5,-6,6,-10,4,3,-7,-55,10,9,-21,32,-11,-13,6,7,10,-7,23,11,-30,-8,6,20,-5,-27,]
contempt = [0,1,0,-1,1,-1,1,-1,1,2,-2,0,-1,0,0,0,0,0,0,2,-2,3,-3,1,1,-1,5,6,-2,-5,2,-1,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
