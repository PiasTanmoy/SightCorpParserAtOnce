import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,0,0,1,-1,1,0,-1,1,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [0,5,6,15,-11,14,-7,17,-12,3,13,-8,4,-7,0,5,-2,5,9,0,23,-14,7,-6,-9,24,]
disgust = [0,0,1,1,-1,0,0,2,0,-2,0,0,1,-1,0,0,0,0,1,-1,0,1,0,0,1,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [-2,3,-4,5,-3,2,-2,1,3,-4,1,-1,3,-2,-1,-1,1,4,1,9,-14,-1,0,9,3,-10,]
neutral = [3,-13,-1,-24,17,-15,6,-23,14,0,-11,7,-9,13,1,-3,1,-12,-8,-11,-4,8,-6,-1,2,-9,]
contempt = [-1,4,-1,3,-1,-3,3,4,-5,4,-4,1,3,-3,-1,-1,0,4,-4,3,-5,7,-2,-2,3,-5,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
