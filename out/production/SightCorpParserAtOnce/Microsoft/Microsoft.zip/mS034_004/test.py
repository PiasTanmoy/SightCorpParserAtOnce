import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,0,0,0,1,0,3,0,0,0,1,0,0,0,1,1,1,1,1,0,1,1,0,0,0,0,0,0,]
anger = [3,2,1,1,2,6,10,1,5,4,6,1,3,9,14,6,8,12,10,7,20,13,15,45,26,52,38,28,]
disgust = [0,0,0,0,0,0,1,0,0,0,0,0,1,0,1,0,1,0,1,0,4,1,0,2,0,1,1,3,]
fear = [0,0,0,0,1,0,3,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,]
sadness = [22,25,4,8,24,14,8,20,9,4,12,17,30,7,10,8,34,11,25,14,22,19,8,16,2,6,5,7,]
neutral = [71,70,92,90,71,74,74,75,83,89,77,80,63,79,67,83,48,70,59,75,45,56,76,33,71,39,49,53,]
contempt = [3,3,2,1,1,5,3,3,3,2,5,1,3,5,7,3,7,5,5,4,9,10,2,3,1,4,7,8,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
