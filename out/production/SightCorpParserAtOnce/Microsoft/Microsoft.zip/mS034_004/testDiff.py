import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,0,0,1,-1,3,-3,0,0,1,-1,0,0,1,0,0,0,0,-1,1,0,-1,0,0,0,0,0,]
anger = [-1,-1,0,1,4,4,-9,4,-1,2,-5,2,6,5,-8,2,4,-2,-3,13,-7,2,30,-19,26,-14,-10,]
disgust = [0,0,0,0,0,1,-1,0,0,0,0,1,-1,1,-1,1,-1,1,-1,4,-3,-1,2,-2,1,0,2,]
fear = [0,0,0,1,-1,3,-3,0,0,0,0,0,0,0,0,0,1,-1,0,0,0,0,0,0,0,0,0,]
sadness = [3,-21,4,16,-10,-6,12,-11,-5,8,5,13,-23,3,-2,26,-23,14,-11,8,-3,-11,8,-14,4,-1,2,]
neutral = [-1,22,-2,-19,3,0,1,8,6,-12,3,-17,16,-12,16,-35,22,-11,16,-30,11,20,-43,38,-32,10,4,]
contempt = [0,-1,-1,0,4,-2,0,0,-1,3,-4,2,2,2,-4,4,-2,0,-1,5,1,-8,1,-2,3,3,1,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
