import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,3,28,94,98,100,100,100,100,100,]
surprise = [0,0,0,0,0,0,0,0,0,0,]
anger = [1,0,0,0,0,0,0,0,0,0,]
disgust = [0,0,0,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,]
sadness = [1,0,0,0,0,0,0,0,0,0,]
neutral = [95,93,69,6,2,0,0,0,0,0,]
contempt = [3,3,3,0,0,0,0,0,0,0,]
x = [1,2,3,4,5,6,7,8,9,10]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
