import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [0,5,3,2,4,31,27,27,39,45,52,54,62,63,65,]
surprise = [0,1,1,1,2,2,1,0,0,0,0,0,0,0,0,]
anger = [1,1,1,2,1,5,14,23,26,23,21,16,12,18,11,]
disgust = [0,1,1,2,1,24,40,38,32,30,27,29,25,17,23,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [1,1,1,1,2,4,5,4,1,1,0,1,0,1,0,]
neutral = [97,82,90,89,91,29,10,5,1,0,0,0,0,0,0,]
contempt = [1,11,4,2,1,5,4,3,1,1,1,1,0,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
