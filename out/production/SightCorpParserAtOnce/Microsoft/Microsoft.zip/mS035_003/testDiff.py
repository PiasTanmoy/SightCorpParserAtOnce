import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happiness = [5,-2,-1,2,27,-4,0,12,6,7,2,8,1,2,]
surprise = [1,0,0,1,0,-1,-1,0,0,0,0,0,0,0,]
anger = [0,0,1,-1,4,9,9,3,-3,-2,-5,-4,6,-7,]
disgust = [1,0,1,-1,23,16,-2,-6,-2,-3,2,-4,-8,6,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,1,2,1,-1,-3,0,-1,1,-1,1,-1,]
neutral = [-15,8,-1,2,-62,-19,-5,-4,-1,0,0,0,0,0,]
contempt = [10,-7,-2,-1,4,-1,-1,-2,0,0,0,-1,0,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
