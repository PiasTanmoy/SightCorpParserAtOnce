import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [86,71,75,63,44,35,33,22,24,41,34,86,72,75,63,44,35,33,22,24,41,34,]
anger = [6,16,15,23,29,42,39,34,30,25,29,6,10,15,23,29,42,39,34,30,25,29,]
disgust = [48,38,51,64,86,92,91,100,100,100,100,48,41,51,64,86,92,91,100,100,100,100,]
fear = [7,14,8,1,0,0,0,0,0,0,0,7,21,8,1,0,0,0,0,0,0,0,]
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [12,9,6,3,8,7,3,3,13,10,8,12,0,6,3,8,7,3,3,13,10,8,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
