import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [-15,4,-12,-19,-9,-2,-11,2,17,-7,52,-14,3,-12,-19,-9,-2,-11,2,17,-7,]
anger = [10,-1,8,6,13,-3,-5,-4,-5,4,-23,4,5,8,6,13,-3,-5,-4,-5,4,]
disgust = [-10,13,13,22,6,-1,9,0,0,0,-52,-7,10,13,22,6,-1,9,0,0,0,]
fear = [7,-6,-7,-1,0,0,0,0,0,0,7,14,-13,-7,-1,0,0,0,0,0,0,]
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [-3,-3,-3,5,-1,-4,0,10,-3,-2,4,-12,6,-3,5,-1,-4,0,10,-3,-2,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
