import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [75,75,75,61,61,63,36,42,16,19,16,10,5,7,]
anger = [7,7,7,0,1,0,0,0,0,0,0,0,0,0,]
disgust = [15,15,15,18,13,23,38,33,40,34,29,30,33,31,]
fear = [0,0,0,0,0,0,21,28,27,24,33,44,31,33,]
happiness = [37,37,37,39,37,30,33,34,43,44,47,49,52,57,]
sadness = [0,0,0,0,0,0,0,1,0,0,0,0,0,0,]
surprise = [29,29,29,33,30,25,7,0,9,0,8,2,0,1,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
