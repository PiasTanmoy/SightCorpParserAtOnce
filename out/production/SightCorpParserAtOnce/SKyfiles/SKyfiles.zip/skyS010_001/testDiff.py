import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [0,0,-14,0,2,-27,6,-26,3,-3,-6,-5,2,]
anger = [0,0,-7,1,-1,0,0,0,0,0,0,0,0,]
disgust = [0,0,3,-5,10,15,-5,7,-6,-5,1,3,-2,]
fear = [0,0,0,0,0,21,7,-1,-3,9,11,-13,2,]
happiness = [0,0,2,-2,-7,3,1,9,1,3,2,3,5,]
sadness = [0,0,0,0,0,0,1,-1,0,0,0,0,0,]
surprise = [0,0,4,-3,-5,-18,-7,9,-9,8,-6,-2,1,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
