import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [-3,7,-10,12,-40,-17,-10,-13,0,0,0,0,0,]
anger = [0,-2,7,-4,10,-24,0,0,0,0,0,0,0,]
disgust = [1,6,-2,-5,14,8,-4,-18,13,-12,-8,-3,1,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [-5,-2,-1,-2,-3,-15,-3,2,-3,5,3,-3,3,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [1,1,2,5,24,25,13,2,0,0,0,0,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
