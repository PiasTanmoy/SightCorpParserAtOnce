import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [73,74,81,80,87,80,71,67,68,45,47,59,49,46,54,47,57,58,]
anger = [36,36,40,39,36,45,58,52,67,68,64,72,74,57,59,64,57,56,]
disgust = [0,7,9,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,]
happiness = [15,13,7,11,16,17,15,16,14,18,16,18,14,15,16,21,18,17,]
sadness = [4,0,0,0,0,0,0,0,7,0,1,0,0,8,0,3,0,2,]
surprise = [13,12,12,13,16,11,6,6,0,0,0,0,0,1,0,2,2,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
