import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [100,98,100,87,93,70,63,54,43,35,6,0,0,0,0,0,0,0,0,]
anger = [42,38,42,48,58,66,82,90,96,100,100,100,100,100,100,100,99,100,97,]
disgust = [0,4,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [16,12,18,16,16,13,12,10,15,15,22,20,20,24,22,21,25,25,23,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [21,14,19,14,10,7,2,3,11,15,7,1,5,2,5,7,5,6,5,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
