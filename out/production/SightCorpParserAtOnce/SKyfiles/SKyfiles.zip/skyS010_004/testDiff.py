import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [-2,2,-13,6,-23,-7,-9,-11,-8,-29,-6,0,0,0,0,0,0,0,]
anger = [-4,4,6,10,8,16,8,6,4,0,0,0,0,0,0,-1,1,-3,]
disgust = [4,-4,0,0,2,-2,0,0,0,0,0,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [-4,6,-2,0,-3,-1,-2,5,0,7,-2,0,4,-2,-1,4,0,-2,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [-7,5,-5,-4,-3,-5,1,8,4,-8,-6,4,-3,3,2,-2,1,-1,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
