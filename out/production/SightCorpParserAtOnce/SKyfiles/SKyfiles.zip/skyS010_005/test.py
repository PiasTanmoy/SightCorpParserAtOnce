import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [83,85,81,93,78,76,77,81,100,68,46,29,0,0,0,0,]
anger = [19,29,26,20,19,32,19,16,21,0,0,1,0,0,0,0,]
disgust = [18,7,14,8,24,23,29,32,37,57,79,100,100,100,100,100,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [10,16,15,16,15,14,7,13,14,21,20,16,16,19,16,18,]
sadness = [0,0,0,6,0,0,8,6,0,0,0,0,0,0,0,0,]
surprise = [12,16,13,14,17,13,13,22,32,34,44,46,49,43,50,41,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
