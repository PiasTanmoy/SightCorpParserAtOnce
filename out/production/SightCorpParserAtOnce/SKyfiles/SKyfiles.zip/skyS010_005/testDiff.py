import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [2,-4,12,-15,-2,1,4,19,-32,-22,-17,-29,0,0,0,]
anger = [10,-3,-6,-1,13,-13,-3,5,-21,0,1,-1,0,0,0,]
disgust = [-11,7,-6,16,-1,6,3,5,20,22,21,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [6,-1,1,-1,-1,-7,6,1,7,-1,-4,0,3,-3,2,]
sadness = [0,0,6,-6,0,8,-2,-6,0,0,0,0,0,0,0,]
surprise = [4,-3,1,3,-4,0,9,10,2,10,2,3,-6,7,-9,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
