import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [71,79,73,58,44,28,11,14,0,5,13,7,11,4,5,]
anger = [15,16,9,9,8,0,0,0,0,0,0,0,0,0,0,]
disgust = [10,13,23,28,25,48,45,34,36,35,18,15,12,16,17,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [23,26,28,31,47,55,70,77,88,90,90,99,97,100,100,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [26,33,25,26,26,30,13,17,2,7,8,8,6,3,7,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
