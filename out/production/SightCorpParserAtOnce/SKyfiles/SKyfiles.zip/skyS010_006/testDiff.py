import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [8,-6,-15,-14,-16,-17,3,-14,5,8,-6,4,-7,1,]
anger = [1,-7,0,-1,-8,0,0,0,0,0,0,0,0,0,]
disgust = [3,10,5,-3,23,-3,-11,2,-1,-17,-3,-3,4,1,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [3,2,3,16,8,15,7,11,2,0,9,-2,3,0,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [7,-8,1,0,4,-17,4,-15,5,1,0,-2,-3,4,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
