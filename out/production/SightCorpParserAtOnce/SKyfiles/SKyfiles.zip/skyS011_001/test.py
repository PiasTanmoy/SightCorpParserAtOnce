import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [100,0,100,0,100,0,100,100,0,100,0,88,94,79,85,0,57,60,0,45,0,45,46,0,37,0,]
anger = [24,94,15,100,20,100,23,18,100,25,89,29,30,42,31,97,44,35,87,41,92,26,28,96,30,88,]
disgust = [25,97,33,97,33,81,28,30,96,42,80,54,73,64,57,84,51,54,78,49,78,47,49,77,52,80,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [18,46,0,53,0,40,1,5,63,0,53,0,0,0,0,62,0,0,75,0,51,0,0,68,0,75,]
surprise = [3,57,10,56,11,59,13,8,47,32,49,50,78,93,100,75,100,100,68,100,59,100,100,61,100,62,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
