import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [-100,100,-100,100,-100,100,0,-100,100,-100,88,6,-15,6,-85,57,3,-60,45,-45,45,1,-46,37,-37,]
anger = [70,-79,85,-80,80,-77,-5,82,-75,64,-60,1,12,-11,66,-53,-9,52,-46,51,-66,2,68,-66,58,]
disgust = [72,-64,64,-64,48,-53,2,66,-54,38,-26,19,-9,-7,27,-33,3,24,-29,29,-31,2,28,-25,28,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [0,0,0,2,-2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [28,-46,53,-53,40,-39,4,58,-63,53,-53,0,0,0,62,-62,0,75,-75,51,-51,0,68,-68,75,]
surprise = [54,-47,46,-45,48,-46,-5,39,-15,17,1,28,15,7,-25,25,0,-32,32,-41,41,0,-39,39,-38,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
