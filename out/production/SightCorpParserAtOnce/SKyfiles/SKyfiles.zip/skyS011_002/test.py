import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [100,0,100,0,100,0,100,0,100,0,100,0,89,73,60,63,47,46,49,38,32,0,36,36,18,23,15,18,15,]
anger = [29,100,42,100,31,100,40,100,26,100,23,100,30,27,36,34,30,40,36,41,49,100,44,44,34,24,33,34,26,]
disgust = [25,97,25,100,22,92,19,100,15,100,0,84,4,0,0,0,0,0,0,0,0,100,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,4,0,0,20,20,23,15,32,21,34,31,0,32,37,31,27,41,38,31,]
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [22,21,7,35,25,28,14,26,48,20,46,23,66,77,83,73,89,77,73,74,74,42,71,53,65,70,72,68,72,]
surprise = [0,62,5,65,0,61,0,66,0,64,0,70,0,0,0,0,0,0,0,0,0,67,0,0,0,0,0,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
