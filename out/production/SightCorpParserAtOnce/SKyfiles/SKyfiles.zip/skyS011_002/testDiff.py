import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [-100,100,-100,100,-100,100,-100,100,-100,100,-100,89,-16,-13,3,-16,-1,3,-11,-6,-32,36,0,-18,5,-8,3,-3,]
anger = [71,-58,58,-69,69,-60,60,-74,74,-77,77,-70,-3,9,-2,-4,10,-4,5,8,51,-56,0,-10,-10,9,1,-8,]
disgust = [72,-72,75,-78,70,-73,81,-85,85,-100,84,-80,-4,0,0,0,0,0,0,0,100,-100,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,4,-4,0,20,0,3,-8,17,-11,13,-3,-31,32,5,-6,-4,14,-3,-7,]
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [-1,-14,28,-10,3,-14,12,22,-28,26,-23,43,11,6,-10,16,-12,-4,1,0,-32,29,-18,12,5,2,-4,4,]
surprise = [62,-57,60,-65,61,-61,66,-66,64,-64,70,-70,0,0,0,0,0,0,0,0,67,-67,0,0,0,0,0,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
