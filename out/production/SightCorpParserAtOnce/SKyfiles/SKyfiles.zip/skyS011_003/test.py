import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [100,0,100,0,100,0,100,0,97,0,78,0,57,0,27,0,10,0,0,0,0,0,0,0,]
anger = [34,100,32,88,31,95,43,98,22,100,23,100,0,100,0,89,0,0,0,92,0,100,0,0,]
disgust = [26,93,31,100,28,100,23,100,22,100,14,97,2,97,0,100,0,0,0,80,0,78,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,23,0,25,0,48,61,71,0,62,0,69,61,]
happiness = [0,0,0,0,0,0,0,0,0,0,4,0,11,0,19,0,17,23,26,0,26,0,26,24,]
sadness = [0,62,0,38,0,58,0,54,0,42,13,38,3,41,0,48,22,11,19,38,0,51,10,7,]
surprise = [14,62,10,64,9,66,5,71,11,65,0,61,1,64,8,74,0,0,0,79,0,75,0,3,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
