import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [-100,100,-100,100,-100,100,-100,97,-97,78,-78,57,-57,27,-27,10,-10,0,0,0,0,0,0,]
anger = [66,-68,56,-57,64,-52,55,-76,78,-77,77,-100,100,-100,89,-89,0,0,92,-92,100,-100,0,]
disgust = [67,-62,69,-72,72,-77,77,-78,78,-86,83,-95,95,-97,100,-100,0,0,80,-80,78,-78,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,23,-23,25,-25,48,13,10,-71,62,-62,69,-8,]
happiness = [0,0,0,0,0,0,0,0,0,4,-4,11,-11,19,-19,17,6,3,-26,26,-26,26,-2,]
sadness = [62,-62,38,-38,58,-58,54,-54,42,-29,25,-35,38,-41,48,-26,-11,8,19,-38,51,-41,-3,]
surprise = [48,-52,54,-55,57,-61,66,-60,54,-65,61,-60,63,-56,66,-74,0,0,79,-79,75,-75,3,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
