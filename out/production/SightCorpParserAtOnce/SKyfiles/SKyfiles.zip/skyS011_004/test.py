import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [100,100,100,96,100,100,100,100,100,92,100,100,92,66,53,49,38,36,43,0,26,33,]
anger = [18,20,23,24,26,27,31,39,52,71,95,98,100,100,100,100,100,100,100,100,100,100,]
disgust = [36,34,34,23,19,30,16,20,21,0,0,0,0,0,0,0,0,0,0,79,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [10,7,8,6,4,2,7,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,0,0,0,0,0,11,9,0,0,2,6,1,8,0,2,2,36,0,0,]
surprise = [10,5,10,6,3,5,3,0,0,0,0,0,0,0,0,0,0,0,0,76,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
