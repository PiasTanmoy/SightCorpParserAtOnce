import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [0,0,-4,4,0,0,0,0,-8,8,0,-8,-26,-13,-4,-11,-2,7,-43,26,7,]
anger = [2,3,1,2,1,4,8,13,19,24,3,2,0,0,0,0,0,0,0,0,0,]
disgust = [-2,0,-11,-4,11,-14,4,1,-21,0,0,0,0,0,0,0,0,0,79,-79,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [-3,1,-2,-2,-2,5,-7,2,-2,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,0,0,0,0,11,-2,-9,0,2,4,-5,7,-8,2,0,34,-36,0,]
surprise = [-5,5,-4,-3,2,-2,-3,0,0,0,0,0,0,0,0,0,0,0,76,-76,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
