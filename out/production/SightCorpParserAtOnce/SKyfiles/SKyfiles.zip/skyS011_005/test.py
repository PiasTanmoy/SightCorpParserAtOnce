import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [100,0,100,0,100,0,100,0,100,0,100,0,100,0,97,72,41,27,24,11,20,0,20,0,]
anger = [30,100,18,100,29,99,29,93,0,96,10,97,10,97,9,18,20,33,38,28,30,99,32,100,]
disgust = [27,95,26,78,45,95,54,100,63,90,68,99,75,100,81,100,100,100,100,100,100,87,100,87,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [4,0,6,0,3,0,4,0,2,0,0,0,1,0,0,0,0,3,3,0,0,0,3,0,]
sadness = [0,46,2,51,0,58,0,53,7,57,0,63,0,52,0,0,0,0,0,0,0,60,0,55,]
surprise = [9,53,8,65,20,63,6,66,9,59,8,61,5,63,5,15,16,18,5,13,6,52,15,49,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
