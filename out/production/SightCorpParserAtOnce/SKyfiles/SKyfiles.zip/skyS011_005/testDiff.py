import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [-100,100,-100,100,-100,100,-100,100,-100,100,-100,100,-100,97,-25,-31,-14,-3,-13,9,-20,20,-20,]
anger = [70,-82,82,-71,70,-70,64,-93,96,-86,87,-87,87,-88,9,2,13,5,-10,2,69,-67,68,]
disgust = [68,-69,52,-33,50,-41,46,-37,27,-22,31,-24,25,-19,19,0,0,0,0,0,-13,13,-13,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [-4,6,-6,3,-3,4,-4,2,-2,0,0,1,-1,0,0,0,3,0,-3,0,0,3,-3,]
sadness = [46,-44,49,-51,58,-58,53,-46,50,-57,63,-63,52,-52,0,0,0,0,0,0,60,-60,55,]
surprise = [44,-45,57,-45,43,-57,60,-57,50,-51,53,-56,58,-58,10,1,2,-13,8,-7,46,-37,34,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
