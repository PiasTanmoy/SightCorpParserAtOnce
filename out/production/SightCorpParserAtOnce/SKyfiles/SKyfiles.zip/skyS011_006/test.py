import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [0,98,100,100,0,90,0,74,41,26,0,0,0,0,0,0,]
anger = [97,16,22,23,97,18,98,9,7,0,10,13,17,18,25,26,]
disgust = [88,32,38,38,97,29,93,19,39,26,29,37,29,27,25,15,]
fear = [0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [0,10,10,13,0,15,0,38,59,85,98,99,100,100,100,99,]
sadness = [17,0,0,0,38,0,13,0,0,0,0,0,0,0,0,0,]
surprise = [73,9,2,6,44,14,73,10,16,11,11,6,4,2,6,3,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
