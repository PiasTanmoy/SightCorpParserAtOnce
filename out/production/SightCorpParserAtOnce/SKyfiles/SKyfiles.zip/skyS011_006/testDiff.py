import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [98,2,0,-100,90,-90,74,-33,-15,-26,0,0,0,0,0,]
anger = [-81,6,1,74,-79,80,-89,-2,-7,10,3,4,1,7,1,]
disgust = [-56,6,0,59,-68,64,-74,20,-13,3,8,-8,-2,-2,-10,]
fear = [0,1,-1,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [10,0,3,-13,15,-15,38,21,26,13,1,1,0,0,-1,]
sadness = [-17,0,0,38,-38,13,-13,0,0,0,0,0,0,0,0,]
surprise = [-64,-7,4,38,-30,59,-63,6,-5,0,-5,-2,-2,4,-3,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
