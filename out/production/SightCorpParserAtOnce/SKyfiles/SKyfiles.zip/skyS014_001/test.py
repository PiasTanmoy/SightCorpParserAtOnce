import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [76,83,96,92,82,80,65,81,62,67,71,34,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [1,0,15,2,4,7,14,3,22,7,3,7,35,28,21,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
disgust = [0,2,0,6,3,0,9,0,6,12,0,20,25,5,1,0,0,1,19,10,2,0,6,19,22,29,17,26,24,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,5,8,29,37,32,6,0,2,0,0,0,0,0,0,0,0,]
happiness = [20,16,21,15,19,18,19,20,22,23,30,37,33,35,39,40,30,30,21,30,25,23,16,15,14,6,8,5,10,]
sadness = [36,34,23,28,33,35,22,9,5,5,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [35,35,36,39,37,25,38,44,43,46,40,51,34,39,45,49,56,68,82,91,92,100,100,100,100,100,100,100,100,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
