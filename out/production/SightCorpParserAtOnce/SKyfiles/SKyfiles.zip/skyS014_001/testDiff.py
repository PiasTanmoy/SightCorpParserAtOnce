import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [7,13,-4,-10,-2,-15,16,-19,5,4,-37,-34,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [-1,15,-13,2,3,7,-11,19,-15,-4,4,28,-7,-7,-21,0,0,0,0,0,0,0,0,0,0,0,0,0,]
disgust = [2,-2,6,-3,-3,9,-9,6,6,-12,20,5,-20,-4,-1,0,1,18,-9,-8,-2,6,13,3,7,-12,9,-2,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,5,3,21,8,-5,-26,-6,2,-2,0,0,0,0,0,0,0,]
happiness = [-4,5,-6,4,-1,1,1,2,1,7,7,-4,2,4,1,-10,0,-9,9,-5,-2,-7,-1,-1,-8,2,-3,5,]
sadness = [-2,-11,5,5,2,-13,-13,-4,0,-5,0,0,0,0,0,0,2,-2,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,1,3,-2,-12,13,6,-1,3,-6,11,-17,5,6,4,7,12,14,9,1,8,0,0,0,0,0,0,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
