import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [-16,-1,-12,-23,4,-17,-23,-9,-3,0,0,0,0,0,0,]
anger = [3,10,0,4,-7,12,-10,9,-13,10,-21,-18,-6,0,0,]
disgust = [0,0,0,0,11,-11,13,6,8,-5,12,13,0,-17,-8,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [1,-4,-1,1,-8,-1,0,-2,7,-3,-1,-3,0,0,0,]
sadness = [-7,2,-11,35,1,6,15,-14,8,-4,11,25,0,0,0,]
surprise = [8,0,-5,-9,-1,0,0,0,0,0,0,4,-3,2,-3,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
