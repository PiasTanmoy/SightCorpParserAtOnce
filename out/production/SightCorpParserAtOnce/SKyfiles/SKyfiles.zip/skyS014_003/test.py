import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [73,71,75,73,76,79,81,75,77,77,78,85,81,75,74,84,77,84,79,82,73,67,40,36,22,16,15,9,0,0,]
anger = [17,19,11,20,13,19,25,28,47,42,36,45,48,36,39,46,36,38,46,37,57,68,63,72,60,64,68,71,76,75,]
disgust = [0,0,3,0,0,0,0,0,5,0,0,0,0,0,0,0,1,0,0,0,0,3,10,23,34,28,23,29,39,33,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,]
happiness = [18,20,15,17,16,17,18,16,11,14,11,9,12,8,13,9,9,15,17,11,8,6,5,2,0,1,1,0,2,7,]
sadness = [40,28,27,24,11,34,11,1,0,0,11,0,0,9,0,1,6,0,0,0,0,0,0,0,0,6,0,22,0,0,]
surprise = [16,18,24,29,24,19,24,35,23,27,27,23,22,20,22,22,31,21,19,29,27,14,21,10,2,0,0,0,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
