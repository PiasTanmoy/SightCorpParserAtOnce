import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [92,83,86,81,88,84,81,73,50,67,39,37,33,26,26,29,25,21,23,]
anger = [7,19,7,17,17,20,21,17,16,18,9,33,30,20,33,35,42,33,38,]
disgust = [2,0,0,5,0,10,13,42,70,88,100,100,100,96,100,100,100,100,100,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [13,13,13,14,13,9,12,10,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [41,28,53,30,23,16,11,2,0,0,0,0,0,6,0,3,4,9,16,]
surprise = [22,18,20,18,19,14,13,25,16,22,31,24,23,21,28,21,21,14,14,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
