import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [-9,3,-5,7,-4,-3,-8,-23,17,-28,-2,-4,-7,0,3,-4,-4,2,]
anger = [12,-12,10,0,3,1,-4,-1,2,-9,24,-3,-10,13,2,7,-9,5,]
disgust = [-2,0,5,-5,10,3,29,28,18,12,0,0,-4,4,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [0,0,1,-1,-4,3,-2,-10,0,0,0,0,0,0,0,0,0,0,]
sadness = [-13,25,-23,-7,-7,-5,-9,-2,0,0,0,0,6,-6,3,1,5,7,]
surprise = [-4,2,-2,1,-5,-1,12,-9,6,9,-7,-1,-2,7,-7,0,-7,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
