import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [53,55,58,67,64,47,44,38,41,28,21,16,17,20,11,11,24,]
anger = [6,6,4,8,2,15,0,0,0,0,0,0,0,0,0,0,0,]
disgust = [2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [20,19,21,19,21,26,31,39,48,65,76,84,91,93,91,93,100,]
sadness = [28,26,25,17,37,0,20,0,0,0,0,0,0,0,0,0,0,]
surprise = [18,27,25,28,28,26,39,34,26,24,26,36,23,33,35,36,34,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
