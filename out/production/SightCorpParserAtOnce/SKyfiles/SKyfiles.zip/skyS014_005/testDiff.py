import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [2,3,9,-3,-17,-3,-6,3,-13,-7,-5,1,3,-9,0,13,]
anger = [0,-2,4,-6,13,-15,0,0,0,0,0,0,0,0,0,0,]
disgust = [-2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [-1,2,-2,2,5,5,8,9,17,11,8,7,2,-2,2,7,]
sadness = [-2,-1,-8,20,-37,20,-20,0,0,0,0,0,0,0,0,0,]
surprise = [9,-2,3,0,-2,13,-5,-8,-2,2,10,-13,10,2,1,-2,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
