import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [70,82,88,75,89,92,79,88,81,72,70,57,54,38,17,22,2,5,4,0,0,0,0,0,0,0,0,0,0,0,]
anger = [39,36,51,37,32,35,36,34,22,16,19,19,13,3,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,]
disgust = [8,13,5,6,6,15,15,15,25,20,10,21,10,0,5,0,0,2,0,0,2,4,0,3,1,8,0,0,0,9,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,9,12,4,4,13,0,0,0,0,0,0,0,0,0,]
happiness = [3,0,0,0,1,1,4,0,2,7,7,1,3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,12,3,1,]
surprise = [23,24,22,20,30,33,39,36,36,42,50,48,49,51,53,50,49,45,57,56,51,64,65,65,64,74,59,63,60,74,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
