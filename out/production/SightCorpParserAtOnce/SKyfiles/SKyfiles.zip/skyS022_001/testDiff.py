import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [12,6,-13,14,3,-13,9,-7,-9,-2,-13,-3,-16,-21,5,-20,3,-1,-4,0,0,0,0,0,0,0,0,0,0,]
anger = [-3,15,-14,-5,3,1,-2,-12,-6,3,0,-6,-10,-3,0,0,0,0,0,0,0,0,0,1,-1,0,0,0,0,]
disgust = [5,-8,1,0,9,0,0,10,-5,-10,11,-11,-10,5,-5,0,2,-2,0,2,2,-4,3,-2,7,-8,0,0,9,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,8,-8,9,3,-8,0,9,-13,0,0,0,0,0,0,0,0,]
happiness = [-3,0,0,1,0,3,-4,2,5,0,-6,2,-2,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,2,-2,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,8,-9,-2,]
surprise = [1,-2,-2,10,3,6,-3,0,6,8,-2,1,2,2,-3,-1,-4,12,-1,-5,13,1,0,-1,10,-15,4,-3,14,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
