import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [81,83,87,69,86,79,60,45,36,18,0,0,0,0,0,0,0,]
anger = [33,15,31,38,15,13,3,7,0,0,0,0,0,0,0,0,0,]
disgust = [27,20,17,14,36,34,38,27,26,27,33,31,30,17,18,11,26,]
fear = [0,0,0,0,0,0,4,13,13,8,27,15,26,40,36,38,27,]
happiness = [0,2,0,1,4,10,13,15,23,21,20,18,23,26,30,32,27,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [11,12,16,17,28,26,29,20,24,33,22,39,23,21,26,27,23,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
