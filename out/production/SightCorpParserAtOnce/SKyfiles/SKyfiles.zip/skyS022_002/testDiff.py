import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [2,4,-18,17,-7,-19,-15,-9,-18,-18,0,0,0,0,0,0,]
anger = [-18,16,7,-23,-2,-10,4,-7,0,0,0,0,0,0,0,0,]
disgust = [-7,-3,-3,22,-2,4,-11,-1,1,6,-2,-1,-13,1,-7,15,]
fear = [0,0,0,0,0,4,9,0,-5,19,-12,11,14,-4,2,-11,]
happiness = [2,-2,1,3,6,3,2,8,-2,-1,-2,5,3,4,2,-5,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [1,4,1,11,-2,3,-9,4,9,-11,17,-16,-2,5,1,-4,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
