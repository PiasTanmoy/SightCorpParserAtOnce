import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [69,67,75,67,76,54,52,50,39,53,44,41,41,35,7,0,0,0,7,10,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [26,36,15,33,31,27,30,18,26,12,0,30,24,18,2,11,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
disgust = [31,20,25,27,19,30,26,35,29,36,45,41,37,38,50,54,53,55,61,56,54,51,53,49,54,50,57,54,53,48,44,46,41,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [4,5,8,9,13,23,30,32,34,32,34,34,38,37,36,34,40,37,44,44,54,59,63,68,72,73,72,79,80,86,91,87,90,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [15,16,19,24,21,33,25,29,31,32,31,26,38,24,31,45,41,40,51,40,32,26,36,35,29,21,25,23,24,21,17,17,20,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
