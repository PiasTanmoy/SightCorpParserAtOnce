import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [10,14,0,0,-10,2,2,6,-4,-13,4,-4,-13,13,-12,-5,0,-11,14,-1,-1,-2,]
anger = [2,-11,4,-6,5,-6,8,-7,1,1,0,7,-2,4,-4,1,8,-11,5,-4,15,-12,]
disgust = [-9,3,-8,7,-1,-6,0,0,0,0,0,0,0,0,5,-5,0,0,0,0,0,0,]
fear = [0,0,9,-9,0,0,0,5,-3,3,-5,3,-2,1,9,-3,-6,18,-16,-3,2,4,]
happiness = [0,0,1,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,0,0,0,0,0,0,0,3,-1,-1,5,1,6,2,0,6,6,-3,0,]
surprise = [3,-5,-6,3,-4,2,-1,-2,0,3,-3,0,0,0,0,0,0,0,0,0,0,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
