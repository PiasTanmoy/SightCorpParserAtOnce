import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [96,90,78,68,78,74,74,76,65,71,61,55,39,34,27,11,4,0,0,0,0,0,0,4,1,0,4,0,0,2,0,11,]
anger = [43,45,45,52,51,55,52,58,59,62,56,71,82,77,78,91,94,100,100,98,94,99,94,96,81,89,87,100,100,82,95,88,]
disgust = [12,4,11,24,17,19,14,5,12,13,17,9,13,1,6,0,1,0,3,2,8,4,0,0,0,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,3,4,0,1,0,0,0,0,0,0,]
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,2,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [18,22,15,17,22,12,12,19,14,18,11,11,9,9,8,7,8,8,8,5,12,0,1,0,4,6,7,0,1,0,2,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
