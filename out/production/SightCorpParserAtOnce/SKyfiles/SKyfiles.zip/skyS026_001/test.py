import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [12,23,19,22,16,18,0,0,0,0,0,0,0,0,0,]
anger = [39,44,45,33,33,20,5,3,0,0,0,0,0,0,0,]
disgust = [54,58,54,47,48,42,54,53,52,46,26,23,27,23,21,]
fear = [7,5,10,0,18,36,24,17,24,22,0,0,1,0,0,]
happiness = [8,1,3,4,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [31,30,25,30,33,44,66,76,82,81,95,100,97,100,97,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
