import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [11,-4,3,-6,2,-18,0,0,0,0,0,0,0,0,]
anger = [5,1,-12,0,-13,-15,-2,-3,0,0,0,0,0,0,]
disgust = [4,-4,-7,1,-6,12,-1,-1,-6,-20,-3,4,-4,-2,]
fear = [-2,5,-10,18,18,-12,-7,7,-2,-22,0,1,-1,0,]
happiness = [-7,2,1,-4,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [-1,-5,5,3,11,22,10,6,-1,14,5,-3,3,-3,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
