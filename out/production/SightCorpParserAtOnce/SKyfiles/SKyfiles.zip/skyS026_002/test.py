import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [15,22,13,8,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [39,29,47,44,44,15,18,1,0,0,1,0,0,3,8,18,]
disgust = [53,38,40,33,31,28,30,25,15,23,30,16,24,12,21,25,]
fear = [12,25,19,38,27,37,44,43,49,35,43,43,37,41,29,22,]
happiness = [1,9,0,7,7,11,3,0,7,7,0,4,4,2,9,4,]
sadness = [0,0,0,0,0,0,2,5,10,8,16,8,22,26,0,0,]
surprise = [23,17,21,14,14,21,7,10,16,16,11,16,12,12,20,16,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
