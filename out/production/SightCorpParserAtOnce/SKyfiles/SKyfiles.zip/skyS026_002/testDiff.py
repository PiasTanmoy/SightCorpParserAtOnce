import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [7,-9,-5,-8,0,0,0,0,0,0,0,0,0,0,0,]
anger = [-10,18,-3,0,-29,3,-17,-1,0,1,-1,0,3,5,10,]
disgust = [-15,2,-7,-2,-3,2,-5,-10,8,7,-14,8,-12,9,4,]
fear = [13,-6,19,-11,10,7,-1,6,-14,8,0,-6,4,-12,-7,]
happiness = [8,-9,7,0,4,-8,-3,7,0,-7,4,0,-2,7,-5,]
sadness = [0,0,0,0,0,2,3,5,-2,8,-8,14,4,-26,0,]
surprise = [-6,4,-7,0,7,-14,3,6,0,-5,5,-4,0,8,-4,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
