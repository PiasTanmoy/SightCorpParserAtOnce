import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [51,49,61,46,21,18,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
disgust = [23,19,18,13,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
fear = [16,20,29,42,69,85,94,98,90,93,99,93,97,89,92,94,93,97,100,90,86,83,84,100,92,90,90,90,93,100,100,100,100,100,100,100,100,100,]
happiness = [11,14,14,13,7,3,2,5,4,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,3,0,1,]
sadness = [44,48,46,39,35,27,21,12,18,33,32,25,40,36,53,52,42,58,39,66,61,60,54,52,51,55,47,50,49,47,39,42,39,40,49,46,39,40,]
surprise = [36,33,31,23,21,29,34,35,31,30,26,32,23,26,20,20,23,14,14,15,20,23,20,25,18,19,28,25,26,28,20,24,27,23,20,23,25,18,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
