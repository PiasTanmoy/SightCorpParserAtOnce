import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [5,-6,-11,-21,-6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
disgust = [2,-4,-2,3,-8,1,6,-3,11,-17,6,3,-10,9,-3,-2,3,5,-3,6,-13,11,-9,2,7,-3,1,-6,-3,5,5,-15,2,-2,-4,0,5,0,-5,2,3,]
fear = [-7,1,6,4,5,19,-11,7,-4,-1,-10,11,-2,2,10,-2,-5,-9,3,-5,5,-7,6,4,-10,14,-7,10,-8,5,3,-11,9,-4,-8,-7,12,-3,3,-8,-5,]
happiness = [0,1,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [12,9,-2,0,13,0,0,-2,-5,2,0,3,1,-4,5,-3,3,-6,2,4,-9,6,3,-2,-7,9,-6,3,3,-12,12,0,0,0,0,0,0,0,0,0,0,]
surprise = [-3,-3,2,2,-6,6,16,-2,-2,0,3,-4,2,-5,0,2,-5,9,3,-6,5,0,-1,-4,9,-11,8,-4,-4,9,-12,8,-6,0,12,-4,-4,1,2,-1,-1,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
