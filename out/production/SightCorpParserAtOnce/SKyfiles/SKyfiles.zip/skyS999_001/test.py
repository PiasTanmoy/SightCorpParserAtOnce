import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [100,100,100,100,100,100,79,39,42,36,38,26,25,31,32,18,31,26,]
anger = [18,16,19,17,30,61,93,100,100,100,100,100,100,100,100,100,100,100,]
disgust = [17,10,3,18,9,1,0,0,0,0,0,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [42,40,38,43,24,39,36,39,26,38,30,33,20,33,31,25,14,14,]
surprise = [21,27,24,21,27,28,19,7,0,0,0,0,2,0,0,3,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
