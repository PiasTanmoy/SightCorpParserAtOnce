import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
neutral_mood = [0,0,0,0,0,-21,-40,3,-6,2,-12,-1,6,1,-14,13,-5,]
anger = [-2,3,-2,13,31,32,7,0,0,0,0,0,0,0,0,0,0,]
disgust = [-7,-7,15,-9,-8,-1,0,0,0,0,0,0,0,0,0,0,0,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
happiness = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [-2,-2,5,-19,15,-3,3,-13,12,-8,3,-13,13,-2,-6,-11,0,]
surprise = [6,-3,-3,6,1,-9,-12,-7,0,0,0,2,-2,0,3,-3,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.plot(x, neutral, '-m', label='neutral')
pylab.plot(x, contempt, '-k', label='contempt')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
