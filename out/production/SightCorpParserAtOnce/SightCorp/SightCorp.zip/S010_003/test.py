import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,0,0,0,1,0,0,2,1,0,1,]
surprise = [0,0,0,0,0,0,1,0,0,0,0,1,0,0,1,0,0,0,]
anger = [3,2,3,3,6,3,10,6,7,9,10,10,6,10,16,11,22,8,]
disgust = [1,0,0,0,0,0,1,0,0,1,1,1,1,0,1,0,2,1,]
fear = [3,3,3,1,2,2,3,2,3,2,1,2,1,2,2,1,1,1,]
sadness = [34,43,40,47,46,72,45,63,63,36,35,48,84,72,41,54,55,54,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
