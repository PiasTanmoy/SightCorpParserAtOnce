import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,1,]
surprise = [0,0,0,0,0,0,0,0,1,2,6,1,1,1,0,0,]
anger = [4,6,4,5,5,3,5,5,6,6,14,6,5,7,6,3,]
disgust = [1,1,0,0,0,0,1,0,1,3,17,18,47,62,79,89,]
fear = [3,2,1,3,2,2,4,4,8,10,15,5,6,3,1,1,]
sadness = [15,36,20,51,25,15,29,42,28,47,26,62,35,20,8,3,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
