import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,]
surprise = [1,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,]
anger = [14,14,24,12,16,24,25,41,43,33,20,8,21,6,20,15,9,4,2,3,]
disgust = [0,0,0,0,0,1,2,5,11,33,55,78,68,85,67,72,81,86,92,91,]
fear = [1,1,1,0,0,0,1,0,1,2,1,0,0,0,0,0,0,0,0,0,]
sadness = [12,14,10,5,7,4,6,4,8,10,6,3,7,3,8,9,6,6,2,3,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
