import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,1,0,0,-1,0,0,0,0,0,0,0,]
surprise = [-1,0,0,0,0,0,0,1,0,0,-1,0,0,0,0,0,0,0,0,]
anger = [0,10,-12,4,8,1,16,2,-10,-13,-12,13,-15,14,-5,-6,-5,-2,1,]
disgust = [0,0,0,0,1,1,3,6,22,22,23,-10,17,-18,5,9,5,6,-1,]
fear = [0,0,-1,0,0,1,-1,1,1,-1,-1,0,0,0,0,0,0,0,0,]
sadness = [2,-4,-5,2,-3,2,-2,4,2,-4,-3,4,-4,5,1,-3,0,-4,1,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
