import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [1,0,1,1,0,0,0,0,0,0,0,1,0,0,0,1,1,0,2,1,1,0,0,0,0,0,0,0,0,0,]
surprise = [5,7,8,8,9,10,13,15,14,26,31,27,35,44,49,43,39,57,63,68,78,87,90,90,92,93,90,89,88,92,]
anger = [7,5,5,6,3,5,3,3,3,4,2,1,2,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,]
disgust = [2,1,2,2,1,1,1,1,2,3,1,2,1,1,1,2,3,1,2,2,1,0,1,0,0,0,0,0,0,0,]
fear = [8,11,6,6,8,8,7,11,8,17,20,30,17,22,30,20,22,26,15,17,13,8,4,6,4,3,7,7,10,4,]
sadness = [8,7,3,5,5,6,4,4,2,7,3,6,7,4,3,7,8,3,4,3,1,0,1,1,0,0,0,1,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
