import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,-1,0,0,0,0,1,6,-3,10,-4,11,-2,-6,3,0,]
surprise = [-3,5,-5,5,3,-4,11,-7,-4,5,0,4,-3,4,4,-5,]
anger = [-2,-2,-2,3,1,-5,0,1,-1,0,0,0,0,0,0,0,]
disgust = [-1,-1,0,1,-1,0,0,4,-2,3,0,0,-1,0,-3,2,]
fear = [1,4,-2,-2,5,3,11,-13,0,1,2,4,3,-6,4,-1,]
sadness = [2,-1,1,-2,0,0,0,1,1,0,0,1,-2,-1,1,1,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
