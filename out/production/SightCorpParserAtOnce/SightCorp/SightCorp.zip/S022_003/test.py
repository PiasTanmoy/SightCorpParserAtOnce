import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [1,0,1,4,1,3,2,10,10,8,7,9,13,14,17,16,13,13,24,31,27,27,47,36,49,55,48,63,69,73,81,66,66,]
surprise = [10,7,11,7,12,5,8,7,10,8,7,8,9,11,8,10,8,9,10,14,15,16,10,11,9,8,9,5,5,4,2,4,5,]
anger = [2,1,8,6,3,2,3,11,7,3,2,3,3,5,10,8,7,7,6,4,3,2,2,2,2,2,2,0,0,0,0,0,0,]
disgust = [1,0,2,3,1,1,1,4,2,2,2,2,2,4,8,4,4,6,9,6,5,4,5,4,3,5,4,3,1,2,1,3,2,]
fear = [8,8,5,4,7,4,4,6,7,6,7,7,10,8,8,13,8,13,13,22,29,30,22,30,23,18,26,21,19,14,13,19,20,]
sadness = [5,5,5,3,3,3,2,4,3,3,3,3,4,4,5,12,8,11,8,4,5,4,3,3,3,3,3,2,1,2,0,2,1,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
