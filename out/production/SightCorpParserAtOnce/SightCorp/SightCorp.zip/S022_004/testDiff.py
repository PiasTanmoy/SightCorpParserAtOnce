import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [1,-1,0,1,-1,0,0,0,0,0,0,0,0,0,5,-5,0,0,0,0,0,0,0,]
surprise = [-3,2,1,-1,0,8,-8,2,-2,6,0,-6,1,2,-10,11,4,-3,-4,1,0,2,-3,]
anger = [0,-1,-1,6,-1,-2,-1,6,-3,1,-1,0,1,-1,54,-52,2,-3,3,1,0,-3,1,]
disgust = [1,-1,0,2,-1,0,0,0,0,0,-1,1,0,-1,6,-5,-1,0,1,-1,0,0,0,]
fear = [-1,4,-3,0,-1,2,1,0,-2,2,11,-14,4,3,-4,2,0,-1,0,-2,3,0,-1,]
sadness = [1,1,-1,1,2,-1,8,-7,0,0,1,1,7,-4,-8,8,2,-5,7,-1,-6,6,-6,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
