import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,1,-1,0,0,1,-1,1,-1,1,-1,1,-1,0,0,0,0,0,0,0,0,0,]
surprise = [7,-4,-3,2,2,-1,1,-3,0,-2,2,2,-5,1,-2,-3,2,0,-1,1,0,-2,1,3,]
anger = [-3,0,0,3,-6,5,2,0,10,6,6,2,21,-1,17,16,-8,5,0,-2,4,6,-7,-10,]
disgust = [-1,0,1,0,-2,1,1,1,0,3,-2,2,-3,3,-4,-1,1,-1,0,0,0,0,0,0,]
fear = [1,0,0,1,2,-1,-2,0,0,0,0,2,-3,1,-2,-1,1,-1,1,-1,0,-1,1,3,]
sadness = [0,0,-1,1,-1,2,0,0,-1,3,0,-1,-1,1,-2,-1,0,-1,1,0,-2,1,1,1,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
