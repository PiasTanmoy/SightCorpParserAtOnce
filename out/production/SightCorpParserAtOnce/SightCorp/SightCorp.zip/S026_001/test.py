import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [1,3,1,1,1,1,0,0,0,0,0,0,0,0,0,]
surprise = [4,8,6,5,12,28,87,93,95,95,96,96,97,96,96,]
anger = [3,4,3,1,2,1,0,0,0,0,0,0,0,0,0,]
disgust = [13,5,6,3,4,3,1,0,0,0,0,0,0,0,0,]
fear = [1,2,1,1,1,4,2,3,3,3,2,3,1,2,3,]
sadness = [2,3,3,3,3,6,2,2,0,0,0,0,0,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
