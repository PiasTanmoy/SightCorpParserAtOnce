import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,1,0,1,1,1,0,1,1,1,0,1,1,1,3,1,]
surprise = [2,3,2,3,3,3,1,4,4,3,2,3,3,6,7,3,]
anger = [2,2,2,3,2,2,1,0,1,1,0,1,0,1,2,1,]
disgust = [3,3,4,6,7,7,4,2,3,3,4,4,3,4,7,7,]
fear = [1,1,0,1,1,2,1,2,1,1,2,1,2,2,2,1,]
sadness = [9,8,7,13,15,36,51,74,69,74,75,70,79,59,53,54,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
