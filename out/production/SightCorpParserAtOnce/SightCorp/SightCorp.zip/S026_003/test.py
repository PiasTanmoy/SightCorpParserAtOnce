import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [2,2,2,1,1,1,2,2,1,2,1,2,1,1,2,]
surprise = [6,8,6,1,4,3,1,1,1,1,1,0,0,0,0,]
anger = [1,1,2,1,2,4,11,21,39,28,54,53,60,64,64,]
disgust = [2,3,4,2,3,8,21,24,34,49,28,36,31,30,26,]
fear = [1,1,1,1,1,1,0,1,0,0,0,0,0,0,0,]
sadness = [5,6,9,3,5,5,5,6,7,4,6,1,2,1,1,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
