import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [2,1,2,3,5,7,24,29,36,48,41,45,60,58,]
surprise = [5,5,5,3,4,3,3,3,4,3,4,3,2,2,]
anger = [1,1,1,1,1,2,3,3,2,2,3,3,2,2,]
disgust = [3,3,4,5,4,11,34,29,25,20,18,19,14,16,]
fear = [0,1,1,0,1,2,3,5,7,5,7,5,3,5,]
sadness = [4,7,7,4,5,6,5,8,10,5,9,10,7,8,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
