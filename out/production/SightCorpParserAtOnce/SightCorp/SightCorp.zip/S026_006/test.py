import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [4,4,6,33,63,86,86,95,98,98,1,98,98,96,]
surprise = [1,3,4,4,6,1,2,0,0,0,1,0,0,0,]
anger = [2,1,2,2,2,1,1,0,0,0,19,0,0,0,]
disgust = [4,5,5,6,5,2,1,0,0,0,24,0,0,0,]
fear = [0,0,0,1,2,1,1,0,0,0,13,0,0,0,]
sadness = [2,5,6,2,2,1,1,0,0,0,35,0,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
