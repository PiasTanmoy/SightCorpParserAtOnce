import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [3,2,3,2,3,5,4,4,3,5,4,5,4,2,2,3,2,2,1,]
anger = [2,4,7,14,13,25,36,30,40,41,68,74,78,74,78,79,64,77,81,]
disgust = [87,87,81,77,79,63,53,58,51,46,21,13,13,20,16,13,30,16,15,]
fear = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [0,0,0,0,0,0,1,1,0,1,0,1,1,0,0,0,0,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
