import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,1,1,1,1,7,7,4,3,3,1,2,3,]
surprise = [3,3,1,2,3,1,4,4,2,1,1,0,0,1,]
anger = [4,8,18,8,20,7,12,12,5,3,4,2,3,4,]
disgust = [0,0,1,0,2,4,4,3,2,1,2,1,1,1,]
fear = [1,1,1,2,5,5,14,41,76,87,81,92,85,80,]
sadness = [1,3,4,4,7,7,5,6,3,1,4,0,2,6,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
