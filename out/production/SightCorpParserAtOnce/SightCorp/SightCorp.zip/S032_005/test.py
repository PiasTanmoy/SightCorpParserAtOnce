import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,10,0,1,6,1,3,1,3,1,2,2,2,1,2,1,9,2,3,3,2,14,2,16,]
surprise = [1,12,1,1,16,2,22,2,6,2,3,20,2,12,2,2,10,1,0,1,0,2,13,1,]
anger = [5,4,18,22,5,18,6,12,4,13,8,4,46,5,11,2,5,3,2,1,0,4,5,7,]
disgust = [2,11,2,2,20,2,22,4,23,5,12,10,21,50,67,87,29,87,88,90,94,72,17,66,]
fear = [1,9,2,1,7,2,5,1,8,1,2,4,2,9,3,1,4,2,2,1,0,2,10,5,]
sadness = [6,27,5,10,23,8,10,8,15,5,4,17,5,4,2,1,17,0,0,0,0,1,21,1,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
