import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [10,-10,1,5,-5,2,-2,2,-2,1,0,0,-1,1,-1,8,-7,1,0,-1,12,-12,14,]
surprise = [11,-11,0,15,-14,20,-20,4,-4,1,17,-18,10,-10,0,8,-9,-1,1,-1,2,11,-12,]
anger = [-1,14,4,-17,13,-12,6,-8,9,-5,-4,42,-41,6,-9,3,-2,-1,-1,-1,4,1,2,]
disgust = [9,-9,0,18,-18,20,-18,19,-18,7,-2,11,29,17,20,-58,58,1,2,4,-22,-55,49,]
fear = [8,-7,-1,6,-5,3,-4,7,-7,1,2,-2,7,-6,-2,3,-2,0,-1,-1,2,8,-5,]
sadness = [21,-22,5,13,-15,2,-2,7,-10,-1,13,-12,-1,-2,-1,16,-17,0,0,0,1,20,-20,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
