import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,4,1,3,3,3,]
surprise = [1,1,1,1,1,1,2,2,2,3,2,3,2,3,4,6,11,11,22,33,45,61,64,87,80,86,85,75,83,]
anger = [20,25,20,15,37,27,23,28,23,38,20,21,15,21,17,23,25,27,22,22,18,16,9,2,3,3,3,4,3,]
disgust = [1,2,1,2,6,3,2,5,3,6,3,5,3,3,5,6,7,6,6,4,5,3,2,1,5,2,2,4,4,]
fear = [2,1,2,2,3,3,3,2,5,3,4,4,6,9,7,8,8,9,8,11,7,5,6,2,3,3,3,7,2,]
sadness = [29,25,31,35,12,17,17,10,18,13,27,13,24,27,25,27,30,34,33,25,18,12,15,3,2,1,1,3,2,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
