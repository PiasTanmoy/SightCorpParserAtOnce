import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,0,0,0,0,1,2,4,7,7,7,6,8,7,7,4,5,3,4,5,4,4,3,3,2,3,]
surprise = [0,1,0,1,1,0,0,0,1,0,0,0,3,3,2,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,0,0,0,]
anger = [15,22,19,27,25,17,21,18,38,21,24,41,23,20,19,13,15,13,20,20,17,32,23,38,41,29,36,32,34,49,48,62,46,]
disgust = [1,1,1,1,1,0,1,1,0,2,2,3,9,10,8,8,5,5,7,6,6,7,5,11,5,5,8,5,6,7,10,5,7,]
fear = [1,1,2,1,2,1,1,0,2,2,2,2,13,21,30,42,40,35,31,28,27,29,40,24,30,31,31,37,29,24,19,13,24,]
sadness = [31,15,25,19,31,38,32,27,14,20,13,7,19,21,15,11,9,11,8,8,16,9,12,9,11,13,8,10,13,6,7,3,5,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
