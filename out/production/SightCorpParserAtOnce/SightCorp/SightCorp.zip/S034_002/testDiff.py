import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,0,0,0,1,1,2,3,0,0,-1,2,-1,0,-3,1,-2,1,1,-1,0,-1,0,-1,1,]
surprise = [1,-1,1,0,-1,0,0,1,-1,0,0,3,0,-1,-1,0,0,0,0,0,0,0,0,-1,1,0,0,0,0,-1,0,0,]
anger = [7,-3,8,-2,-8,4,-3,20,-17,3,17,-18,-3,-1,-6,2,-2,7,0,-3,15,-9,15,3,-12,7,-4,2,15,-1,14,-16,]
disgust = [0,0,0,0,-1,1,0,-1,2,0,1,6,1,-2,0,-3,0,2,-1,0,1,-2,6,-6,0,3,-3,1,1,3,-5,2,]
fear = [0,1,-1,1,-1,0,-1,2,0,0,0,11,8,9,12,-2,-5,-4,-3,-1,2,11,-16,6,1,0,6,-8,-5,-5,-6,11,]
sadness = [-16,10,-6,12,7,-6,-5,-13,6,-7,-6,12,2,-6,-4,-2,2,-3,0,8,-7,3,-3,2,2,-5,2,3,-7,1,-4,2,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
