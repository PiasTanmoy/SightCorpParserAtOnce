import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [35,12,28,30,37,22,41,25,32,51,44,39,34,42,29,24,35,38,37,45,51,53,38,76,60,65,63,75,66,72,55,57,41,29,28,18,27,]
disgust = [1,0,2,1,1,1,1,1,1,2,1,1,1,2,1,1,1,1,2,2,1,1,2,11,25,27,25,14,18,13,34,37,53,69,69,79,69,]
fear = [1,1,1,1,2,2,1,1,2,1,2,1,1,2,1,1,1,2,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [15,26,19,22,17,22,23,21,15,20,20,13,13,9,23,20,14,19,20,9,14,15,27,3,7,4,4,4,6,8,5,1,2,0,0,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
