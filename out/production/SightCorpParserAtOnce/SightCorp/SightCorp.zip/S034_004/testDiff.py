import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
surprise = [0,1,0,0,0,0,-1,1,0,0,0,0,-1,1,0,0,-1,1,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
anger = [-23,16,2,7,-15,19,-16,7,19,-7,-5,-5,8,-13,-5,11,3,-1,8,6,2,-15,38,-16,5,-2,12,-9,6,-17,2,-16,-12,-1,-10,9,]
disgust = [-1,2,-1,0,0,0,0,0,1,-1,0,0,1,-1,0,0,0,1,0,-1,0,1,9,14,2,-2,-11,4,-5,21,3,16,16,0,10,-10,]
fear = [0,0,0,1,0,-1,0,1,-1,1,-1,0,1,-1,0,0,1,-1,0,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,]
sadness = [11,-7,3,-5,5,1,-2,-6,5,0,-7,0,-4,14,-3,-6,5,1,-11,5,1,12,-24,4,-3,0,0,2,2,-3,-4,1,-2,0,0,0,]

x = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
