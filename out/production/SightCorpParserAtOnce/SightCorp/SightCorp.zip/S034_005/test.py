import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,6,41,71,80,87,84,89,]
surprise = [0,0,1,1,1,0,0,0,0,0,]
anger = [69,25,40,25,15,5,5,2,2,2,]
disgust = [1,1,1,7,10,7,8,5,8,5,]
fear = [0,1,1,2,3,2,1,0,1,0,]
sadness = [4,4,3,7,4,4,2,1,1,1,]
x = [1,2,3,4,5,6,7,8,9,10]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
