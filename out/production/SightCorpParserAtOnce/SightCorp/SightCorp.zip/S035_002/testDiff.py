import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,0,0,0,0,0,0,]
surprise = [0,-3,3,-3,4,-2,-2,0,1,]
anger = [1,-1,1,-1,1,0,-1,0,0,]
disgust = [0,-1,0,0,1,1,-2,0,0,]
fear = [1,-1,2,-1,3,-4,0,-1,1,]
sadness = [55,-67,28,-13,34,-5,-3,2,23,]

x = [2,3,4,5,6,7,8,9,10]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('diff_graph.png')
pylab.close(1)
