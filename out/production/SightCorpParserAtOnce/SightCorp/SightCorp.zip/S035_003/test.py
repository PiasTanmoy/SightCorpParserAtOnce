import numpy as np
import matplotlib.pyplot as plt
import pylab 
# evenly sampled time at 200ms intervals
#t = np.arange(0., 5., 0.2)
happy = [0,0,0,2,0,1,2,6,20,50,48,50,41,54,62,40,]
surprise = [15,26,15,5,13,24,22,19,12,8,2,1,2,1,1,0,]
anger = [0,0,0,18,0,1,2,2,4,5,4,4,5,6,3,4,]
disgust = [1,2,2,6,3,5,8,28,38,22,37,40,47,35,30,52,]
fear = [2,5,3,34,4,7,8,6,6,3,2,0,1,1,1,0,]
sadness = [5,9,7,3,11,10,6,5,4,1,1,0,1,0,0,0,]
x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

pylab.plot(x, happy, '-v', label='happy')
pylab.plot(x, surprise, '-b', label='surprise')
pylab.plot(x, anger, '-y', label='anger')
pylab.plot(x, disgust, '-g', label='disgust')
pylab.plot(x, fear, '-p', label='fear')
pylab.plot(x, sadness, '-r', label='sadness')
pylab.legend(loc='upper left')
pylab.savefig('graph.png')
pylab.close(1)
